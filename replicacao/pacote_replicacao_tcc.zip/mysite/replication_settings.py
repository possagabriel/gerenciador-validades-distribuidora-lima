"""Configuração local do pacote de replicação do estudo demonstrativo."""
import os

os.environ.setdefault('DJANGO_DEBUG', '1')
from .settings import *  # noqa: F401,F403,E402

DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': BASE_DIR / 'replicacao.sqlite3'}}
ALLOWED_HOSTS = ['localhost', '127.0.0.1', 'testserver']
LANGUAGE_CODE = 'pt-br'
