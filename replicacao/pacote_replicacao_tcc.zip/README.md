# Replicação do caso demonstrativo do TCC

Este pacote reúne o backend e o painel da revisão `11a9e089309e3f6fc90160694ba88c525fe69d4c`,
os registros sintéticos do caso demonstrativo e um roteiro de verificação.
O arquivo `origem.json` registra a revisão e o SHA-256 dos arquivos originais.
O backend e o painel foram desenvolvidos por Darlan José dos Santos.
O aplicativo móvel foi desenvolvido por Gabriel Possa Lima.

Os arquivos `mysite/replication_settings.py`, `preparar_cenario.py` e
`verificar_cenario.py` organizam a execução deste pacote. O cenário usa
SQLite em um arquivo local chamado `replicacao.sqlite3`. A configuração
principal do projeto mantém PostgreSQL.

## Preparar o ambiente

Use Python 3.12 ou superior. A verificação registrada foi executada com
Python 3.14.10, Django 6.0.7 e Django REST Framework 3.17.1.
Extraia o ZIP em uma pasta e execute os comandos dentro dela.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python manage.py migrate --settings=mysite.replication_settings
python preparar_cenario.py
python verificar_cenario.py
```

O usuário `gerente1`, a senha `senha-teste-123` e o CPF repetido
`22222222222` são dados fictícios do cenário. A preparação pode ser
executada novamente e conserva o cenário já criado. A configuração local
usa a chave de desenvolvimento prevista em `mysite/settings.py`.

## Registros do cenário

| Registro | Valores preparados |
|---|---|
| Suco | Categoria Bebidas, 20 unidades, preço de R$ 12,50, custo de R$ 8,75 e validade em três dias |
| Código do suco | `7891234567890` |
| Iogurte | Categoria Frios, 10 unidades, custo de R$ 3,50 e validade vencida há cinco dias |
| Regra da categoria Bebidas | 25% de desconto quando faltarem até dez dias para vencer |

As datas são calculadas em relação ao momento de preparação. Os dados
foram usados no caso demonstrativo e derivam de `test_mobile_flow.py`,
`test_prejuizo_view.py` e `test_api_lotes.py`.

## Resultados esperados

`verificar_cenario.py` usa a API do pacote para obter um JWT, consultar o
filtro crítico, localizar o código do suco, consultar a sugestão de R$ 9,38
e verificar o total de R$ 35,00 do lote vencido. O script também registra
uma saída de três unidades e confere a passagem de 20 para 17 unidades.
Essa operação é revertida ao fim da verificação e o saldo volta a 20.

O resultado aparece em JSON no terminal. O arquivo
`resultado_verificado.json` contém a saída obtida na conferência do pacote.

## Abrir o painel ou conectar o aplicativo

```bash
python manage.py runserver --settings=mysite.replication_settings 127.0.0.1:8000
```

Abra `http://127.0.0.1:8000/` para acessar o painel. Use as credenciais
fictícias indicadas acima. A API está sob `/api/`.

No aplicativo, copie `.env.example` para `.env` e configure
`EXPO_PUBLIC_API_BASE_URL` com a origem da API, sem `/api` no final.
Para acessar pelo celular na rede local, acrescente o endereço do
computador a `ALLOWED_HOSTS` em `mysite/replication_settings.py`, inicie o
servidor em `0.0.0.0:8000` e use essa origem no aplicativo.

## Executar os testes do backend

```bash
DJANGO_DEBUG=1 python manage.py test produtos gerente usuarios --settings=mysite.test_settings
```

Na conferência do pacote em 19/11/2026, passaram os 99 testes.
`testes_verificados.txt` registra a saída. A medição de cobertura do artigo
foi executada em 17/11/2026 e está documentada no relatório do repositório
móvel. A conferência deste pacote executou os testes e o caso demonstrativo.
