"""Confere a API real do pacote e reverte a saída ao terminar a demonstração."""
import json
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.replication_settings')
import django
django.setup()

from django.db import transaction
from produtos.models import Lote, Produto
from rest_framework.test import APIClient

client = APIClient()
login = client.post('/api/token/', {'username': 'gerente1', 'password': 'senha-teste-123'}, format='json')
assert login.status_code == 200, login.data
client.credentials(HTTP_AUTHORIZATION='Bearer ' + login.data['access'])
suco = Produto.objects.get(nome='Suco')
lote = Lote.objects.get(produto=suco)
criticos = client.get('/api/lotes/', {'nivel_vencimento': 2})
assert criticos.status_code == 200
assert any(item['id'] == lote.pk for item in criticos.data['results'])
sku = client.get('/api/produto-skus/', {'codigo_barras': '7891234567890'})
assert sku.status_code == 200 and sku.data[0]['produto'] == suco.pk
sugestoes = client.get('/api/lotes/sugestoes-desconto/')
assert sugestoes.status_code == 200
preco = next(item for item in sugestoes.data['sugestoes'] if item['lote_id'] == lote.pk)
assert preco['preco_sugerido'] == 9.38, preco
suco.refresh_from_db()
assert suco.preco_venda == 12.5
relatorio = client.get('/api/lotes/relatorio-prejuizo/')
assert relatorio.status_code == 200 and relatorio.data['prejuizo_total'] == 35
assert lote.quantidade == 20, 'A verificação espera o saldo inicial do cenário.'
with transaction.atomic():
    saida = client.post(f'/api/lotes/{lote.pk}/movimentos/',
                       {'tipo': 'SAIDA', 'quantidade': 3, 'motivo': 'Conferência do cenário demonstrativo'}, format='json')
    assert saida.status_code == 201, saida.data
    saldo = saida.data['lote']['quantidade']
    assert saldo == 17
    transaction.set_rollback(True)
lote.refresh_from_db()
assert lote.quantidade == 20
print(json.dumps({'autenticacao': 'aprovada', 'lote_critico': 'localizado', 'codigo_barras': 'associado ao suco',
                  'preco_cadastrado': 12.5, 'preco_sugerido': 9.38, 'saldo_antes': 20,
                  'saldo_apos_saida_de_3': saldo, 'movimentacao_revertida': True,
                  'prejuizo_do_lote_vencido': 35}, ensure_ascii=False, indent=2))
