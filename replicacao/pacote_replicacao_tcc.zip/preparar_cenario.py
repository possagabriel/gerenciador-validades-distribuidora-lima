"""Prepara os mesmos registros sintéticos usados no caso descrito no artigo."""
from datetime import timedelta
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.replication_settings')
import django
django.setup()

from django.db import transaction
from django.utils import timezone
from produtos.models import Categoria, Lote, Produto, ProdutoSKU, RegraDesconto
from usuarios.models import Usuario

with transaction.atomic():
    if Usuario.objects.filter(username='gerente1').exists():
        print('O cenário já foi preparado neste banco de replicação.')
    else:
        if Usuario.objects.exists() or Produto.all_objects.exists():
            raise RuntimeError('A preparação exige um banco de replicação novo.')
        Usuario.objects.create_user(username='gerente1', password='senha-teste-123',
                                    cpf='22222222222', tipo_funcionario=Usuario.TipoFuncionario.GERENTE)
        bebidas = Categoria.objects.create(nome='Bebidas')
        suco = Produto.objects.create(nome='Suco', categoria=bebidas, preco_venda=12.5)
        ProdutoSKU.objects.create(produto=suco, codigo_barras='7891234567890')
        Lote.objects.create(produto=suco, quantidade=20, custo_unitario_compra=8.75,
                            data_validade=timezone.now() + timedelta(days=3))
        frios = Categoria.objects.create(nome='Frios', dias_atencao=15, dias_critico=5)
        iogurte = Produto.objects.create(nome='Iogurte', categoria=frios, preco_venda=5.99)
        Lote.objects.create(produto=iogurte, quantidade=10, custo_unitario_compra=3.5,
                            data_validade=timezone.now() - timedelta(days=5))
        RegraDesconto.objects.create(categoria=bebidas, percentual=25, dias_para_vencimento=10)
        for lote in Lote.objects.select_related('produto__categoria'):
            lote.nivel_vencimento = lote.calcular_nivel_vencimento()
            lote.save(update_fields=['nivel_vencimento'])
        print('Cenário preparado. Usuário fictício gerente1, senha de teste senha-teste-123.')
