"""Acrescenta um pequeno catálogo de demonstração sem alterar registros existentes."""

from datetime import timedelta

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from produtos.models import Categoria, Lote, Produto, ProdutoSKU, RegraDesconto


CATEGORIAS = (
    ("Laticínios [DEMO]", 30, 7),
    ("Bebidas [DEMO]", 30, 7),
    ("Mercearia [DEMO]", 30, 7),
    ("Higiene [DEMO]", 30, 7),
)

# nome, categoria, preço de venda, código para QR, quantidade, custo, dias até vencer
PRODUTOS = (
    ("[DEMO] Leite integral 1 L", "Laticínios [DEMO]", 6.99, "TCC-DEMO-LEITE-1L", 24, 4.20, 5),
    ("[DEMO] Iogurte natural 170 g", "Laticínios [DEMO]", 4.99, "TCC-DEMO-IOGURTE-170G", 36, 2.80, 12),
    ("[DEMO] Queijo mussarela 500 g", "Laticínios [DEMO]", 22.90, "TCC-DEMO-QUEIJO-500G", 18, 14.00, 25),
    ("[DEMO] Suco de uva 1 L", "Bebidas [DEMO]", 12.90, "TCC-DEMO-SUCO-1L", 30, 7.50, 7),
    ("[DEMO] Água mineral 500 ml", "Bebidas [DEMO]", 2.99, "TCC-DEMO-AGUA-500ML", 72, 1.20, 365),
    ("[DEMO] Arroz branco 5 kg", "Mercearia [DEMO]", 28.90, "TCC-DEMO-ARROZ-5KG", 20, 18.00, 180),
    ("[DEMO] Biscoito integral 200 g", "Mercearia [DEMO]", 7.90, "TCC-DEMO-BISCOITO-200G", 40, 4.10, 20),
    ("[DEMO] Pão de forma 500 g", "Mercearia [DEMO]", 9.90, "TCC-DEMO-PAO-500G", 8, 5.40, -3),
    ("[DEMO] Sabonete 90 g", "Higiene [DEMO]", 3.49, "TCC-DEMO-SABONETE-90G", 48, 1.60, 270),
)

# categoria, percentual, janela de dias antes do vencimento
REGRAS = (
    ("Laticínios [DEMO]", 10.0, 30),
    ("Laticínios [DEMO]", 20.0, 7),
    ("Bebidas [DEMO]", 10.0, 15),
    ("Mercearia [DEMO]", 8.0, 30),
)


class Command(BaseCommand):
    help = "Adiciona produtos, lotes, descontos e itens restauráveis de demonstração. Pode ser executado novamente."

    @transaction.atomic
    def handle(self, *args, **options):
        contagem = {"categorias": 0, "produtos": 0, "codigos": 0, "lotes": 0, "regras": 0, "excluidos": 0}
        categorias = {}

        for nome, dias_atencao, dias_critico in CATEGORIAS:
            categoria, criada = Categoria.all_objects.get_or_create(
                nome=nome, defaults={"dias_atencao": dias_atencao, "dias_critico": dias_critico}
            )
            categorias[nome] = categoria
            contagem["categorias"] += criada

        for nome, nome_categoria, preco, codigo, quantidade, custo, dias in PRODUTOS:
            produto, criado = Produto.all_objects.get_or_create(
                nome=nome, categoria=categorias[nome_categoria], defaults={"preco_venda": preco}
            )
            contagem["produtos"] += criado
            sku, sku_criado = ProdutoSKU.objects.get_or_create(
                codigo_barras=codigo, defaults={"produto": produto}
            )
            if sku.produto_id != produto.pk:
                raise CommandError(f"O código {codigo} já pertence a outro produto.")
            contagem["codigos"] += sku_criado
            if produto.deletado_em is None and not Lote.all_objects.filter(produto=produto).exists():
                lote = Lote(
                    produto=produto,
                    quantidade=quantidade,
                    custo_unitario_compra=custo,
                    data_validade=timezone.now() + timedelta(days=dias),
                )
                lote.nivel_vencimento = lote.calcular_nivel_vencimento()
                lote.save()
                contagem["lotes"] += 1

        for nome_categoria, percentual, dias in REGRAS:
            _, criada = RegraDesconto.objects.get_or_create(
                categoria=categorias[nome_categoria], percentual=percentual, dias_para_vencimento=dias
            )
            contagem["regras"] += criada

        categoria_excluida, criada = Categoria.all_objects.get_or_create(
            nome="[DEMO] Categoria para restaurar",
            defaults={"dias_atencao": 30, "dias_critico": 7},
        )
        if criada:
            categoria_excluida.delete()
            contagem["categorias"] += 1
            contagem["excluidos"] += 1

        produto_excluido, criado = Produto.all_objects.get_or_create(
            nome="[DEMO] Produto para restaurar",
            categoria=categorias["Mercearia [DEMO]"],
            defaults={"preco_venda": 5.90},
        )
        if criado:
            produto_excluido.delete()
            contagem["produtos"] += 1
            contagem["excluidos"] += 1

        produto_lote, criado = Produto.all_objects.get_or_create(
            nome="[DEMO] Macarrão integral 500 g",
            categoria=categorias["Mercearia [DEMO]"],
            defaults={"preco_venda": 6.90},
        )
        contagem["produtos"] += criado
        if produto_lote.deletado_em is None and not Lote.all_objects.filter(produto=produto_lote).exists():
            lote = Lote(
                produto=produto_lote,
                quantidade=15,
                custo_unitario_compra=3.80,
                data_validade=timezone.now() + timedelta(days=45),
            )
            lote.nivel_vencimento = lote.calcular_nivel_vencimento()
            lote.save()
            lote.delete()
            contagem["lotes"] += 1
            contagem["excluidos"] += 1

        self.stdout.write(self.style.SUCCESS(
            "Dados de demonstração adicionados: " + ", ".join(f"{valor} {nome}" for nome, valor in contagem.items())
        ))
